<?php
/**
 * @package OpenUserMapPlugin
 */

namespace OpenUserMapPlugin\Pages;

use \OpenUserMapPlugin\Base\BaseController;

class Frontend extends BaseController
{
    public function register()
    { 
      // Shortcodes
      add_action('init', array($this, 'set_shortcodes'));

      if ( oum_fs()->is__premium_only() ):
        if ( oum_fs()->can_use_premium_code() ):

          //PRO: Add user location within registration
          if(get_option('oum_enable_add_user_location')):
            add_action('register_form', array($this, 'render_block_add_user_location__premium_only'));
            add_action('user_register', array($this, 'add_user_location__premium_only'));
          endif;

        endif;
      endif;
    }

    /**
     * Setup Shortcodes
     */
    public function set_shortcodes()
    {
      // EXIT if inside Elementor Backend
      // Check if Elementor installed and activated
		  if ( did_action( 'elementor/loaded' ) ) {

        if(\Elementor_OUM_Addon\Plugin::is_elementor_backend()) {
            error_log('OUM: prevented shortcode rendering inside Elementor');
            return;
        }

      }

      // Render Map
      add_shortcode('open-user-map', array($this, 'render_block_map'));

      //PRO: Render Image Gallery (Shortcode)
      if ( oum_fs()->is__premium_only() ):
        if ( oum_fs()->can_use_premium_code() ):

          add_shortcode('open-user-map-gallery', array($this, 'render_block_gallery__premium_only'));

        endif;
      endif;

      //PRO: Render Location Value (Shortcode)
      if ( oum_fs()->is__premium_only() ):
        if ( oum_fs()->can_use_premium_code() ):

          add_shortcode('open-user-map-location', array($this, 'render_block_location__premium_only'));

        endif;
      endif;

      // Unregister incompatible 3rd party scripts
      add_action( 'wp_footer', array($this, 'remove_incompatible_3rd_party_scripts') );

      // Whitelisting inline script for Complianz
      add_filter ( 'cmplz_script_service',
        function( $class, $total_match, $found ) {

          if ( $found && false !== strpos( $total_match, 'oum-inline-js' ) ) {
            $class = 'cmplz-native'; // add cmplz-script for Marketing and cmplz-stats for Statistics
          }

          return $class;
        }, 10 , 3
      );
    }

    /**
     * Unregister incompatible 3rd party scripts
     */
    public function remove_incompatible_3rd_party_scripts()
    {
        foreach($this->oum_incompatible_3rd_party_scripts as $item) {
            wp_deregister_script ( $item );
        }
    }
}
