<?php
/**
 * The Template for displaying the profile posts tab content.
 *
 * This template can be overridden by copying it to yourtheme/wpum/profiles/posts.php
 *
 * HOWEVER, on occasion WPUM will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @version 1.0.0
 */
 

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

  

// $the_query = wpum_get_posts_for_profile( $data->user->ID );

// Replaced with
 /*
$the_query = wpum_get_posts_for_profile( $data->user->ID, array(
	'post_type' => 'oum-location',
 ) );
 */
 /*
 $the_query = wpum_get_posts_for_profile( $data->user->ID, array(
	'post_type' => 'oum-location',
	'post_status' => 'any'
) );
 */





 
?>








<div style="padding-right: 30px; background-color: #e0eeff; ">  
<?php        

    $current_user = wp_get_current_user();
    $user_id = $current_user->ID;

    if($user_id) {
      
        $date = date('F Y');
        $username = $current_user->user_login;
    
        echo "Your credit report for <strong>$date</strong>: <br><br>\n";
        
        // Get the last subscription order for the current user
        
        $args = array(
            'customer' => $user_id,
            'status' => array('wc-active', 'wc-pending', 'wc-on-hold', 'wc-cancelled', 'wc-pending-cancel', 'wc-expired', 'wc-failed'),
            'limit' => 1,
            'type' => 'shop_subscription',
            'orderby' => 'date',
            'order' => 'DESC',
        );
        $orders = wc_get_orders($args);
        
        //    var_dump(empty($orders));
        //    var_dump(current($orders)->get_status());
        //    var_dump(current($orders)->get_id());
        
        // If there is any last subscription, get it's status
        if($orders) {
            $order = current($orders);
            $items = $order->get_items();
            $product_name = '';
                foreach ( $items as $item ) {
                    $product = $item->get_product();
                    if ( $product ) {
                        $product_name = $product->get_name();
                        break;
                    }
                }
            $status = $order->get_status();
        }    
            
            
       // If user has not subscribed after registration or is a regular user who canceled a subscription
        if (empty($orders) || (($status == 'cancelled') && in_array('regular', (array) $current_user->roles) )) {
                
                // if regular user
                if (in_array('regular', (array) $current_user->roles)) {
                    echo "Hi $username (<i>" . implode(', ', $current_user->roles) . "</i> user)<br>";
                    echo 'You are a regular user. You can upgrade your role by subscribing to Plus or Advanced plans from <a href="/shop/" target="_blank" style="text-decoration: underline; color: #2271b1;">Here</a>';
                    echo "<br>Your total credit for $date: 1 location\n";
                          $allowed_credit = 1;
        
                          $args = array(
                              'post_type'      => 'oum-location',
                              'author'         => $current_user->ID,
                              'posts_per_page' => -1,
                              'date_query'     => array(
                                  array(
                                      'year'  => date( 'Y' ),
                                      'month' => date( 'm' ),
                                  ),
                              ),
                          );
        
                        $posts_query = new WP_Query( $args );
                        $used_credit = $posts_query->found_posts;
                        
                    echo "<br>Used credit: <a href='/profile/{$current_user->user_login}/posts' target='_blank' style='text-decoration: underline; color: #2271b1; a:hover {
                                text-decoration: none;
                            }'>$used_credit location(s)</a> published\n\n";
                        
                    $remaining_credit = $allowed_credit - $used_credit;
                    echo "<br>Remaining credit: $remaining_credit location(s)\n";
                        
                    if ($remaining_credit <= 0) {
                          echo '<br>If you want to replace a location, first delete the old one from <a href="/profile/' . $current_user->user_login . '/posts" target="_blank" style="text-decoration: underline; color: #2271b1;">Here</a><br>';
                    }
                  
                    $args = array(
                            'post_type'      => 'oum-location',
                            'author'         => $current_user->ID,
                            'post_status'    => array('draft', 'pending'),
                            'posts_per_page' => -1,
                    );
                        
                    $posts_query = new WP_Query( $args );
                    $draft_posts = $posts_query->found_posts;
                        
                    echo "<br>Under review: <a href='/profile/{$current_user->user_login}/posts' target='_blank' style='text-decoration: underline; color: #2271b1; a:hover {
                                text-decoration: none;
                            }'>$draft_posts location(s)</a> \n";
                        
                    $total_submitted = $used_credit + $draft_posts;
                        
                    echo "<br>Total submitted: $total_submitted location(s)";
                    
                    
                } elseif (in_array('plus', (array) $current_user->roles)) {
                  echo "Hi $username (<i>" . implode(', ', $current_user->roles) . "</i> user)<br>";
                  echo 'You are not subscribed yet. Please subscribe to Plus subscription from <a href="/product/plus-subscription/" target="_blank" style="text-decoration: underline; color: #2271b1;">Here</a>';
                  
                } elseif (in_array('advanced', (array) $current_user->roles)) {
                  echo "Hi $username (<i>" . implode(', ', $current_user->roles) . "</i> user)<br>";
                  echo 'You are not subscribed yet. Please subscribe to Advanced subscription from <a href="/product/advanced-subscription/" target="_blank" style="text-decoration: underline; color: #2271b1;">Here</a>';
                  
                } elseif (in_array('business', (array) $current_user->roles)) {
                  echo "Hi $username (<i>" . implode(', ', $current_user->roles) . "</i> user)<br>";
                  echo 'You are not subscribed yet. Please subscribe to Business subscription from <a href="/product/business-subscription" target="_blank" style="text-decoration: underline; color: #2271b1;">Here</a>';
                }
        
            } else {
                // If the user is subscribed, output the name and status of the subscribed product
                $order = current($orders);
                $items = $order->get_items();
                $product_name = '';
                foreach ( $items as $item ) {
                    $product = $item->get_product();
                    if ( $product ) {
                        $product_name = $product->get_name();
                        break;
                    }
                }
                $status = $order->get_status();
        //        echo $status;
                if ($status == 'active') {
                    
                    
                    // Show the subscription and credit info
                    
                    echo "Hi $username (<i>" . implode(', ', $current_user->roles) . "</i> user)<br>";
                    echo "Your subscription is active for <strong>" . $product_name . "</strong><br>";
                        
                        if (in_array('regular', (array) $current_user->roles)) {
                          echo "Your total credit for $date: 1 location\n";
                          $allowed_credit = 1;
                        } elseif (in_array('plus', (array) $current_user->roles)) {
                          echo "Your total credit for $date: 5 locations\n";
                          $allowed_credit = 5;
                        } elseif (in_array('advanced', (array) $current_user->roles)) {
                          echo "Your total credit for $date: 20 locations\n";
                          $allowed_credit = 20;
                        } elseif (in_array('business', (array) $current_user->roles)) {
                          echo "Your allowed credit: 1 location.\n";
                          $allowed_credit = 1;
                        }
                        
                        if (in_array('business', (array) $current_user->roles)) {
                          $args = array(
                              'post_type'      => 'oum-location',
                              'author'         => $current_user->ID,
                              'posts_per_page' => -1,
                          );
                        } else {
                          $args = array(
                              'post_type'      => 'oum-location',
                              'author'         => $current_user->ID,
                              'posts_per_page' => -1,
                              'date_query'     => array(
                                  array(
                                      'year'  => date( 'Y' ),
                                      'month' => date( 'm' ),
                                  ),
                              ),
                          );
                        }
                        
                        $posts_query = new WP_Query( $args );
                        $used_credit = $posts_query->found_posts;
                        
                        echo "<br>Used credit: <a href='/profile/{$current_user->user_login}/posts' target='_blank' style='text-decoration: underline; color: #2271b1; a:hover {
                                text-decoration: none;
                            }'>$used_credit location(s)</a> published\n\n";
                        
                        $remaining_credit = $allowed_credit - $used_credit;
                        echo "<br>Remaining credit: $remaining_credit location(s)\n";
                        
                        if ($remaining_credit <= 0) {
                          echo '<br>If you want to replace a location, first delete the old one from <a href="/profile/' . $current_user->user_login . '/posts" target="_blank" style="text-decoration: underline; color: #2271b1;">Here</a><br>';
                        }
                        
                         $args = array(
                            'post_type'      => 'oum-location',
                            'author'         => $current_user->ID,
                            'post_status'    => array('draft', 'pending'),
                            'posts_per_page' => -1,
                        );
                        
                        $posts_query = new WP_Query( $args );
                        $draft_posts = $posts_query->found_posts;
                        
                        echo "<br>Under review: <a href='/profile/{$current_user->user_login}/posts' target='_blank' style='text-decoration: underline; color: #2271b1; a:hover {
                                text-decoration: none;
                            }'>$draft_posts location(s)</a> \n";
                            
                        $total_submitted = $used_credit + $draft_posts;
                        
                        echo "<br>Total submitted: $total_submitted location(s)";
                        
                        $remaining_submissions = $allowed_credit - $used_credit - $draft_posts;
                        echo "<br>Remaining submissions: $remaining_submissions location(s)";
                    
                } elseif ($status == 'pending') {
                    echo "Your subscription is pending approval for <strong>" . $product_name . "</strong>";
                } elseif ($status == 'on-hold') {
                    echo "Your subscription is on hold for <strong>" . $product_name . "</strong>";
                } elseif ($status == 'cancelled') {
                    echo "Hi $username (<i>" . implode(', ', $current_user->roles) . "</i> user)<br>";
                    echo "Your subscription for <strong>" . $product_name . "</strong> has been cancelled. You can subscribe again from " . '<a href="/shop/" target="_blank" style="text-decoration: underline; color: #2271b1;">Here</a>';
                } elseif ($status == 'switched') {
                    echo "Your subscription for <strong>" . $product_name . "</strong> has been switched to a new product.";
                } elseif ($status == 'expired') {
                    echo "Your subscription for <strong>" . $product_name . "</strong> has expired.";
                } elseif ($status == 'pending-cancel') {
                    echo "Hi $username (<i>" . implode(', ', $current_user->roles) . "</i> user)<br>";
                    echo "Your subscription for <strong>" . $product_name . "</strong> is pending cancellation.";
                } elseif ($status == 'pending-suspension') {
                    echo "Your subscription for <strong>" . $product_name . "</strong> is pending suspension.";
                } elseif ($status == 'pending-termination') {
                    echo "Your subscription for <strong>" . $product_name . "</strong> is pending termination.";
                }
            
        }
    }
?>
</div>

<!-- End New code -->          


        
      <!-- New code about credits-->
                
        <div style="padding-right: 30px; background-color: #e0eeff; ">  
    <?php
        
        $current_user = wp_get_current_user();
        $user_id = $current_user->ID;
        

        if($user_id) {    
            $args = array(
                'customer' => $user_id,
                'status' => array('wc-active', 'wc-pending', 'wc-on-hold', 'wc-cancelled', 'wc-pending-cancel', 'wc-expired', 'wc-failed'),
                'limit' => 1,
                'type' => 'shop_subscription',
                'orderby' => 'date',
                'order' => 'DESC',
            );
            $orders = wc_get_orders($args);
            $order = current($orders);
    //        $status = $order->get_status();
    //        echo ($status == 'active');
    //        if ($status == 'active') {
            
                $current_user = wp_get_current_user();
                $username = $current_user->user_login;
                $date = date('F Y');
                
//                echo "Hi $username (<i>" . implode(', ', $current_user->roles) . "</i> user)<br>";
                
                if (in_array('regular', (array) $current_user->roles)) {
//                  echo "Your total credit for $date: 1 location\n";
                  $allowed_credit = 1;
                } elseif (in_array('plus', (array) $current_user->roles)) {
//                  echo "Your total credit for $date: 5 locations\n";
                  $allowed_credit = 5;
                } elseif (in_array('advanced', (array) $current_user->roles)) {
//                  echo "Your total credit for $date: 20 locations\n";
                  $allowed_credit = 20;
                } elseif (in_array('business', (array) $current_user->roles)) {
//                  echo "Your allowed credit: 1 location.\n";
                  $allowed_credit = 1;
                }
                
                if (in_array('business', (array) $current_user->roles)) {
                  $args = array(
                      'post_type'      => 'oum-location',
                      'author'         => $current_user->ID,
                      'posts_per_page' => -1,
                  );
                } else {
                  $args = array(
                      'post_type'      => 'oum-location',
                      'author'         => $current_user->ID,
                      'posts_per_page' => -1,
                      'date_query'     => array(
                          array(
                              'year'  => date( 'Y' ),
                              'month' => date( 'm' ),
                          ),
                      ),
                  );
                }
                
                $posts_query = new WP_Query( $args );
                $used_credit = $posts_query->found_posts;
                
//               echo "<br>Used credit: <a href='/profile/{$current_user->user_login}/posts' target='_blank' style='text-decoration: underline; color: #2271b1; a:hover {
//                        text-decoration: none;
//                    }'>$used_credit location(s)</a> published\n\n";
                
                $remaining_credit = $allowed_credit - $used_credit;
//                echo "<br>Remaining credit: $remaining_credit location(s)\n";
                
                if ($remaining_credit <= 0) {
//                  echo '<br>If you want to replace a location, first delete the old one from <a href="/profile/' . $current_user->user_login . '/posts" target="_blank" style="text-decoration: underline; color: #2271b1;">Here</a><br>';
                }
                
                
                
                
                 $args = array(
                    'post_type'      => 'oum-location',
                    'author'         => $current_user->ID,
                    'post_status'    => array('draft', 'pending'),
                    'posts_per_page' => -1,
                );
                
                $posts_query = new WP_Query( $args );
                $draft_posts = $posts_query->found_posts;
                
//                echo "<br>Under review: <a href='/profile/{$current_user->user_login}/posts' target='_blank' style='text-decoration: underline; color: #2271b1; a:hover {
//                        text-decoration: none;
//                    }'>$draft_posts location(s)</a> \n";
                
                
                
                $total_submitted = $used_credit + $draft_posts;
                
//                echo "<br>Total submitted: $total_submitted location(s)";
                $remaining_submissions = $allowed_credit - $used_credit - $draft_posts;
//                echo "<br>Remaining submissions: $remaining_submissions location(s)";
        }
    ?>

        </div>   
        <br>
        
        
        <!-- End New code --> 
 
 
<?php 
 

// Reset the custom query, if any
wp_reset_query();

$posts_per_page = 10; // Set to -1 to retrieve all posts
$the_query = new WP_Query( array(
	'post_type' => 'oum-location',
	'post_status' => 'any',
	'author' => $data->user->ID,
	'paged' => get_query_var('paged'), // Use 'paged' for pagination
	'posts_per_page' => $posts_per_page,
) );


// end replace

?>

<?php if (! is_user_logged_in() ) {  wp_redirect( '/log-in' );} ?>


<div id="profile-posts">
	
	<?php if ( $the_query->have_posts() ) : ?>


		<?php
		while ( $the_query->have_posts() ) :
			$the_query->the_post();
			?>

			<div class="wpum-post" id="wpum-post-<?php echo esc_attr( the_id() ); ?>">

				<!--  Customizations -->
				<strong><?php the_title(); ?></strong>
				
                <!-- Display the '_oum_location_image' custom field -->
                
                  <div class="wpum-post-thumbnail">
                    <?php if ( $location_image = get_post_meta( get_the_ID(), '_oum_location_image', true ) ) : ?>
                      <img src="<?php echo esc_url( $location_image ); ?>" alt="<?php echo esc_attr( get_the_title() ); ?>" class="wpum-post-thumbnail-image" />
                    <?php endif; ?>
                  </div>
                
				
				<?php do_action( 'wpum_profile_posts_after_title' ); ?>
				<ul class="wpum-post-meta">
				    <li>
				        <?php
                        $taxonomy = 'oum-type'; // taxonomy slug
                        $terms = get_the_terms(get_the_ID(), $taxonomy);
                        if ($terms && !is_wp_error($terms)) {
                            $term_names = array();
                            foreach ($terms as $term) {
                                $term_names[] = $term->name;
                            }
                            $term_list = join(', ', $term_names);
                            echo '<strong>Category:</strong> ' . $term_list .' - ';
                        }
                        ?>
				    </li>
					<li>
						<strong><?php esc_html_e( 'Posted on:', 'wp-user-manager' ); ?></strong>
						<?php echo get_the_date(); ?> 
					</li> - 
                    <li>
    				<strong><?php esc_html_e( 'Post ID:', 'wp-user-manager' ); ?></strong>
    				        <?php echo esc_html( get_the_ID() ); ?>
			        </li> - 
			        <li>
                        <strong><?php esc_html_e( 'Status:', 'wp-user-manager' ); ?></strong>
                        <?php echo get_post_status(); ?>
                    </li>
                    <li>
                        <?php
                            // Get the post ID
                            $post_id = get_the_ID();
                            
                            // Get the value of the "reviewer_note" field for this post
                            $reviewer_note = get_field('reviewer_note', $post_id);
                            // Output the value of the "reviewer_note" field
                            if ($reviewer_note) {
                                echo "\n"; // Move to the next line
                                echo '<p> - <strong>Reviewer note:</strong> ' . $reviewer_note . '</p>';
                            }
                            ?>
                    </li>
				</ul>
				
				
				
				<!--  Customizations: View on map -->
                <?php
                $taxonomy = 'oum-type'; // taxonomy slug
                $terms = get_the_terms(get_the_ID(), $taxonomy);
                if ($terms && !is_wp_error($terms)) {
                    $term_names = array();
                    foreach ($terms as $term) {
                        $term_names[] = $term->name;
                    }
                    $term_list = join(', ', $term_names);
                
                    // Check for the categories and set the corresponding link and link text using a switch statement.
                    switch (true) {
                        case in_array('Add your Business (Only business accounts)', $term_names):
                            $link = esc_url(home_url('/add-your-business/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Adventure and outdoor activities', $term_names):
                            $link = esc_url(home_url('/adventure-and-outdoor-activities/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Adventure sports destinations', $term_names):
                            $link = esc_url(home_url('/adventure-sports-destinations/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Agricultural and farming destinations', $term_names):
                            $link = esc_url(home_url('/agricultural-and-farming-destinations/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Architectural structures and landmarks', $term_names):
                            $link = esc_url(home_url('/architectural-structures-and-landmarks/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Art and cultural locations', $term_names):
                            $link = esc_url(home_url('/art-and-cultural-locations/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Beaches and riversides', $term_names):
                            $link = esc_url(home_url('/beaches-and-riversides/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Botanical gardens, zoos, and aquariums', $term_names):
                            $link = esc_url(home_url('/botanical-gardens-zoos-and-aquariums/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Cityscapes and landmarks', $term_names):
                            $link = esc_url(home_url('/cityscapes-and-landmarks/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Cooking experiences and destinations', $term_names):
                            $link = esc_url(home_url('/cooking-experiences-and-destinations/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Cooking experiences and destinations', $term_names):
                            $link = esc_url(home_url('/cooking-experiences-and-destinations/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Craft and artisan destinations', $term_names):
                            $link = esc_url(home_url('/craft-and-artisan-destinations/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Cruise experience and destinations', $term_names):
                            $link = esc_url(home_url('/cruise-experiences-and-destinations/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Educational and research institutions', $term_names):
                            $link = esc_url(home_url('/educational-and-research-institutions/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Entertainment locations', $term_names):
                            $link = esc_url(home_url('/entertainment-locations/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Exercise, yoga, and fitness experiences and locations', $term_names):
                            $link = esc_url(home_url('/exercise-yoga-and-fitness-experiences-and-locations/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Exhibitions and conferences', $term_names):
                            $link = esc_url(home_url('/exhibitions-and-conferences/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Fashion and beauty experiences or locations', $term_names):
                            $link = esc_url(home_url('/fashion-and-beauty-experiences-or-locations/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Festivals, concerts, and events', $term_names):
                            $link = esc_url(home_url('/festivals-concerts-and-events/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;                            
                        case in_array('Fishing and hunting experiences and locations', $term_names):
                            $link = esc_url(home_url('/fishing-and-hunting-experiences-and-locations/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Food and drink destinations', $term_names):
                            $link = esc_url(home_url('/food-and-drink-destinations/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Health and wellness experiences and locations', $term_names):
                            $link = esc_url(home_url('/health-and-wellness-experiences-and-locations/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Hiking and camping destinations', $term_names):
                            $link = esc_url(home_url('/hiking-and-camping-destinations/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Historic and heritage sites', $term_names):
                            $link = esc_url(home_url('/historic-and-heritage-sites/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Hotels and resorts', $term_names):
                            $link = esc_url(home_url('/hotels-and-resorts/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Lifestyle and personal development experiences and locations', $term_names):
                            $link = esc_url(home_url('/lifestyle-and-personal-development-experiences-and-locations/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Museums and galleries', $term_names):
                            $link = esc_url(home_url('/museums-and-galleries/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Music and dance events, experiences, and locations', $term_names):
                            $link = esc_url(home_url('/music-and-dance-events-experiences-and-locations/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Natural landmarks and scenic views', $term_names):
                            $link = esc_url(home_url('/natural-landmarks-and-scenic-views/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Nightlife locations', $term_names):
                            $link = esc_url(home_url('/nightlife-locations/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;     
                        case in_array('Other', $term_names):
                            $link = esc_url(home_url('/other/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Parks', $term_names):
                            $link = esc_url(home_url('/parks/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;        
                        case in_array('Religious and spiritual sites', $term_names):
                            $link = esc_url(home_url('/religious-and-spiritual-sites/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Road trips and scenic drives', $term_names):
                            $link = esc_url(home_url('/road-trips-and-scenic-drives/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;     
                        case in_array('Shopping locations', $term_names):
                            $link = esc_url(home_url('/shopping-locations/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Snow and ice sports destinations', $term_names):
                            $link = esc_url(home_url('/snow-and-ice-sports-destinations/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Spas, massage, and wellness centers', $term_names):
                            $link = esc_url(home_url('/spas-massage-and-wellness-centers/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Sports events, activities, and venues', $term_names):
                            $link = esc_url(home_url('/sports-events-activities-and-venues/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Technology and innovation destinations', $term_names):
                            $link = esc_url(home_url('/technology-and-innovation-destinations/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        case in_array('Theme and amusement parks', $term_names):
                            $link = esc_url(home_url('/theme-and-amusement-parks/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;    
                        case in_array('Water sports, pool, and marine destinations', $term_names):
                            $link = esc_url(home_url('/water-sports-pool-and-marine-destinations/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;                            
                        case in_array('Wildlife and nature reserves', $term_names):
                            $link = esc_url(home_url('/wildlife-and-nature-reserves/?markerid=' . get_the_ID()));
                            $link_text = 'View on map';
                            break;
                        default:
                            // If none of the specified cases match, you can set a default behavior here.
                            $link = ''; // Set a default link if needed.
                            $link_text = ''; // Set default link text if needed.
                    }
                
                    // Output the link if any of the cases matched.
                    if ($link && $link_text) {
                        echo '<a href="' . $link . '" class="view-on-map">' . $link_text . '</a>';
                    }
                
                }
                ?>
                

				<!-- End of View on map-->
				
				
				
				<?php
                $custom_fields = get_post_meta( get_the_ID(), '_oum_location_key', true );
                if ( isset( $custom_fields['custom_fields'][1674347088519] ) ) {
                    $instagram_url = $custom_fields['custom_fields'][1674347088519];
                    echo '<p><a target="blank" href="' . esc_url( $instagram_url ) . '">Instagram post URL</a></p>';
                }
                ?>
                
                
                
                

                
                
                <?php
                $custom_fields = get_post_meta( get_the_ID(), '_oum_location_key', true );
                if ( ! empty( $custom_fields['custom_fields'][1675831363208] ) ) {
                    $business_url = $custom_fields['custom_fields'][1675831363208];
                    echo '<p><a target="_blank" href="' . esc_url( $business_url ) . '">Business website URL</a></p>';
                }
                ?>
                
                
                <?php
                $custom_fields = get_post_meta( get_the_ID(), '_oum_location_key', true );
                if ( ! empty( $custom_fields['custom_fields'][1679718583200] ) ) {
                    $business_address = $custom_fields['custom_fields'][1679718583200];
                    echo  '<p><strong>Business address:</strong> ' . $business_address . '</p>';
                }
                ?>
                
                <?php
                $custom_fields = get_post_meta( get_the_ID(), '_oum_location_key', true );
                if ( ! empty( $custom_fields['custom_fields'][1679718824674] ) ) {
                    $business_phone = $custom_fields['custom_fields'][1679718824674];
                    echo  '<p><strong>Business phones:</strong> ' . $business_phone . '</p>';
                }
                ?>
				
				
				<?php do_action( 'wpum_profile_posts_after_meta' ); ?>
				
			
				
<?php if (current_user_can('delete_post', get_the_ID())) : ?>
    <a href="<?php echo esc_url(get_delete_post_link(get_the_ID())); ?>" class="wpum-post-delete-link" onclick="return confirm('Are you sure you want to delete this post?');"><?php esc_html_e('Delete', 'wp-user-manager'); ?></a>
<?php endif; ?>




                
            
				
			</div>
			

		<?php endwhile; ?>
		
		

		<div id="profile-pagination">
			<?php
				echo wp_kses_post( paginate_links( array(
					'base'         => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
					'total'        => $the_query->max_num_pages,
					'current'      => max( 1, get_query_var( 'paged' ) ),
					'format'       => '?paged=%#%',
					'show_all'     => false,
					'type'         => 'plain',
					'end_size'     => 2,
					'mid_size'     => 1,
					'prev_next'    => true,
					'prev_text'    => sprintf( '<i></i> %1$s', esc_html__( 'Newer Posts', 'wp-user-manager' ) ),
					'next_text'    => sprintf( '%1$s <i></i>', esc_html__( 'Older Posts', 'wp-user-manager' ) ),
					'add_args'     => false,
					'add_fragment' => '',
				) ) );
			?>
		</div>

		<?php wp_reset_postdata(); ?>

	<?php else : ?>

		<?php
			WPUM()->templates
				->set_template_data( array(
					// translators: %s user display name
					'message' => sprintf( esc_html__( '%s has not submitted any posts yet.', 'wp-user-manager' ), apply_filters( 'wpum_user_display_name', $data->user->display_name, $data->user ) ),
				) )
				->get_template_part( 'messages/general', 'warning' );
		?>

	<?php endif; ?>

</div>


