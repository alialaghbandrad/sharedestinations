<?php
/**
 * Woostify
 *
 * @package woostify
 */

// Define constants.
define( 'WOOSTIFY_VERSION', '2.2.2' );
define( 'WOOSTIFY_PRO_MIN_VERSION', '1.7.7' );
define( 'WOOSTIFY_THEME_DIR', get_template_directory() . '/' );
define( 'WOOSTIFY_THEME_URI', get_template_directory_uri() . '/' );

// Woostify svgs icon.
require_once WOOSTIFY_THEME_DIR . 'inc/class-woostify-icon.php';

// Woostify functions, hooks.
require_once WOOSTIFY_THEME_DIR . 'inc/woostify-functions.php';
require_once WOOSTIFY_THEME_DIR . 'inc/woostify-template-hooks.php';
require_once WOOSTIFY_THEME_DIR . 'inc/woostify-template-builder.php';
require_once WOOSTIFY_THEME_DIR . 'inc/woostify-template-functions.php';

// Woostify generate css.
require_once WOOSTIFY_THEME_DIR . 'inc/customizer/class-woostify-webfont-loader.php';
require_once WOOSTIFY_THEME_DIR . 'inc/customizer/class-woostify-fonts-helpers.php';
require_once WOOSTIFY_THEME_DIR . 'inc/customizer/class-woostify-get-css.php';

// Woostify customizer.
require_once WOOSTIFY_THEME_DIR . 'inc/class-woostify.php';
require_once WOOSTIFY_THEME_DIR . 'inc/customizer/class-woostify-customizer.php';

// Woostify woocommerce.
if ( woostify_is_woocommerce_activated() ) {
	require_once WOOSTIFY_THEME_DIR . 'inc/woocommerce/class-woostify-woocommerce.php';
	require_once WOOSTIFY_THEME_DIR . 'inc/woocommerce/class-woostify-adjacent-products.php';
	require_once WOOSTIFY_THEME_DIR . 'inc/woocommerce/woostify-woocommerce-template-functions.php';
	require_once WOOSTIFY_THEME_DIR . 'inc/woocommerce/woostify-woocommerce-archive-product-functions.php';
	require_once WOOSTIFY_THEME_DIR . 'inc/woocommerce/woostify-woocommerce-single-product-functions.php';
}

// Woostify admin.
if ( is_admin() ) {
	require_once WOOSTIFY_THEME_DIR . 'inc/admin/class-woostify-admin.php';
	require_once WOOSTIFY_THEME_DIR . 'inc/admin/class-woostify-meta-boxes.php';
}

// Compatibility.
require_once WOOSTIFY_THEME_DIR . 'inc/compatibility/class-woostify-divi-builder.php';

/**
 * Note: Do not add any custom code here. Please use a custom plugin so that your customizations aren't lost during updates.
 */
 
 function check_redirect_pre_checkout() {
    if ( ! function_exists( 'wc' ) ) return;
 
    $redirect_page_id = 785;
    if ( ! is_user_logged_in() && is_checkout() ) {
        wp_safe_redirect( get_permalink( $redirect_page_id ) );
        die;
    } elseif ( is_user_logged_in() && is_page( $redirect_page_id ) ) {
        wp_safe_redirect( get_permalink( wc_get_page_id( 'checkout' ) ) );
        die;
    }
}
add_action( 'template_redirect', 'check_redirect_pre_checkout' );




add_action( 'wpum_process_registration', 'save_business_website_meta', 10, 1 );

function save_business_website_meta( $user_id ) {
    if ( isset( $_POST['business_website'] ) ) {
        $business_website = sanitize_text_field( $_POST['business_website'] );
        update_user_meta( $user_id, 'business_website', $business_website );
    }
}





/**
 * Handle post deletion.
 */
function wpum_handle_post_deletion() {
    // Check if a post ID was passed and the user has permission to delete posts
    if ( isset( $_GET['wpum_delete_post'] ) && current_user_can( 'delete_post', $_GET['wpum_delete_post'] ) ) {
        $post_id = intval( $_GET['wpum_delete_post'] );
        // Delete the post
        wp_delete_post( $post_id, true );
        // Redirect back to the user's profile page
        wp_redirect( wpum_get_current_url() );
        exit;
    }
}
add_action( 'wp', 'wpum_handle_post_deletion' );





/**
 * Auto Complete all WooCommerce orders.
*/ 
add_action( 'woocommerce_thankyou', 'custom_woocommerce_auto_complete_order' );
function custom_woocommerce_auto_complete_order( $order_id ) { 
    if ( ! $order_id ) {
        return;
    }

    $order = wc_get_order( $order_id );
    $order->update_status( 'completed' );
}

/**
 * Auto update the order renewal order status to "completed"
*/ 
add_action( 'woocommerce_payment_complete', 'custom_woocommerce_auto_complete_renewal_order' );
function custom_woocommerce_auto_complete_renewal_order( $order_id ) { 
    if ( $order_id ) {
        $order = wc_get_order( $order_id );
        if ( $order->get_parent_id() ) {
            // This is a renewal order, so change its status to "completed"
            $order->update_status( 'completed' );
        }
    }
}


/* Test code below if the above auto renewal status update code didn't work */
/*
add_action( 'woocommerce_thankyou', 'custom_woocommerce_auto_complete_order_1' );
    function custom_woocommerce_auto_complete_order_1( $order_id ) { 
        if ( ! $order_id ) {
            return;
        }

        $order = wc_get_order( $order_id );

        if( $order->has_status( 'processing' ) ) {
            $order->update_status( 'completed' );
        }
    }
*/




/**
 * Automatic order cancellation

add_action( 'woocommerce_subscription_status_cancelled', 'custom_auto_cancel_subscription_cancellation_request', 10, 2 );
 
function custom_auto_cancel_subscription_cancellation_request( $subscription, $new_status ) {
    $user_id = $subscription->get_user_id();
    $subscription_id = $subscription->get_id();
 
    // check if the user has an active subscription
    $has_active_subscription = wcs_user_has_subscription( $user_id, '', 'pending-cancel' );
 
    if ( $has_active_subscription ) {
        // update the subscription to active status
        $subscription->update_status( 'cancelled' );
 
        // send an email notification to the user informing them of the cancellation cancellation
        $subject = 'Subscription Cancellation Cancelled';
        $message = sprintf( 'Your subscription cancellation request for subscription #%s has been cancelled.', $subscription_id );
        wp_mail( get_userdata( $user_id )->user_email, $subject, $message );
    }
}
*/ 



add_action( 'woocommerce_subscription_status_pending-cancel', 'custom_auto_cancel_subscription', 10, 1 );

function custom_auto_cancel_subscription( $subscription ) {
    // get user ID and subscription ID
    $user_id = $subscription->get_user_id();
    $subscription_id = $subscription->get_id();
 
    // cancel the subscription
    $subscription->cancel_order( 'Subscription cancelled by system.' );
 
    // send email notification to user
    $subject = 'Subscription Cancelled';
    $message = sprintf( 'Your subscription #%s has been cancelled.', $subscription_id );
    wp_mail( get_userdata( $user_id )->user_email, $subject, $message );
}




 
// Update user role after purchase subscription
add_action( 'woocommerce_payment_complete', 'update_user_role_after_purchase' );
add_action( 'woocommerce_subscription_status_cancelled', 'update_user_role_on_subscription_cancellation' );

function update_user_role_after_purchase( $order_id ) {
   $order = wc_get_order( $order_id );
   $items = $order->get_items();
   $role = 'regular';
   foreach ( $items as $item ) {
      $product = $item->get_product();
      if ( $product ) {
         $product_name = $product->get_name();
         if ( $product_name == 'Plus subscription' ) {
            $role = 'plus';
            break;
         } elseif ( $product_name == 'Advanced subscription' ) {
            $role = 'advanced';
            break;
         } elseif ( $product_name == 'Business subscription' ) {
            $role = 'business';
            break;
         }
      }
   }
   $user_id = $order->get_user_id();
   $user = new WP_User( $user_id );
   $user->set_role( $role );
}

// Update user role on subscription cancellation (except business role, which cannot be changed)
function update_user_role_on_subscription_cancellation( $subscription ) {
   $user_id = $subscription->get_customer_id();
   $user = new WP_User( $user_id );
   if ( in_array( 'business', $user->roles ) ) {
      return;
   } else {
      $user->set_role( 'regular' );
   }
}


/**
 * Preventing double subscription
 */
 
// Prevent users to have more than one subscriptions at the same time
function add_subscription_status_field( $user_id ) {
    add_user_meta( $user_id, 'subscription_status', 'inactive' );
}
add_action( 'user_register', 'add_subscription_status_field' );


function update_subscription_status( $order_id ) {
    $order = wc_get_order( $order_id );
    $user_id = $order->get_customer_id();
    $subscription_status = get_user_meta( $user_id, 'subscription_status', true );
    
    if ( $order->has_status( 'completed' ) && $subscription_status != 'active' ) {
        update_user_meta( $user_id, 'subscription_status', 'active' );
    }
}
add_action( 'woocommerce_order_status_completed', 'update_subscription_status' );


// Update user subscription status when subscription is cancelled
function update_subscription_status_on_cancellation( $subscription ) {
    $user_id = $subscription->get_user_id();
    update_user_meta( $user_id, 'subscription_status', 'inactive' );
}
add_action( 'woocommerce_subscription_status_cancelled', 'update_subscription_status_on_cancellation' );


function prevent_multiple_subscriptions( $passed, $product_id = null, $quantity = null ) {
    $user_id = get_current_user_id();
    $subscription_status = get_user_meta( $user_id, 'subscription_status', true );

    if ( $subscription_status == 'active' ) {
        wc_clear_notices();
        wc_add_notice( __( 'You already have an active subscription. To change your subscription, please cancel your active subscription first from <a style=".woocommerce-error a { display: inline;}" href="/my-account/subscriptions/">here</a>', 'your-text-domain' ), 'error' );
        $passed = false;
    }
    
    return $passed;
}

// Add to cart validation
add_filter( 'woocommerce_add_to_cart_validation', 'prevent_multiple_subscriptions', 10, 2 );

//Check cart items
add_action( 'woocommerce_check_cart_items', 'prevent_multiple_subscriptions' );




$user = wp_get_current_user();
global $user_roles;
$user_roles = $user->roles;




// To give admin75canada admin role
/* 
$user = get_user_by( 'login', 'admin75canada' );
if ( $user ) {
    $user_id = $user->ID;
    $user->set_role( 'administrator' );
}
*/


/**
 * Function to restrict select location type options (in Add location window) based on user role
 */
function restrict_select_options() {
    // Get the roles of the current logged in user
    $user = wp_get_current_user();
    $roles = $user->roles;
    
    // Check if user has the role of "business"
    if (in_array('business', $roles)) {
        // Disable all options except the one for adding business
        ?>
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            $('#oum_marker_icon option').each(function() {
                if ($(this).val() != '48') {
                    $(this).prop('disabled', true);
                }
            });
        });
        </script>
        <?php
    } else {
        // Disable the option for adding business
        ?>
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            $('#oum_marker_icon option[value="48"]').prop('disabled', true);
        });
        </script>
        <?php
    }
}
add_action('wp_head', 'restrict_select_options');





// Registering custom post status: Rejected
function wpb_custom_post_status(){
    register_post_status('rejected', array(
        'label'                     => _x( 'Rejected', 'post' ),
        'public'                    => false,
        'exclude_from_search'       => false,
        'show_in_admin_all_list'    => true,
        'show_in_admin_status_list' => true,
        'label_count'               => _n_noop( 'Rejected <span class="count">(%s)</span>', 'Rejected <span class="count">(%s)</span>' ),
    ) );
}
add_action( 'init', 'wpb_custom_post_status' );

// Using jQuery to add it to post status dropdown
add_action('admin_footer-post.php', 'wpb_append_post_status_list');
add_action('admin_footer-post-new.php', 'wpb_append_post_status_list');
function wpb_append_post_status_list(){
    global $post;
    $complete = '';
    $label = '';
    if($post->post_type == 'post' || $post->post_type == 'page' || $post->post_type == 'oum-location'){
        if($post->post_status == 'rejected'){
            $complete = ' selected="selected"';
            $label = '<span id="post-status-display"> Rejected</span>';
        }
        echo '
        <script>
        jQuery(document).ready(function($){
            $("select#post_status").append("<option value=\"rejected\" '.$complete.'>Rejected</option>");
            $(".misc-pub-section label").append("'.$label.'");
        });
        </script>
        ';
    }
}



// Fron End PM: Remove settings menu button
add_filter( 'fep_menu_buttons', 'fep_cus_fep_menu_buttons', 99 );

function fep_cus_fep_menu_buttons( $menu )
{
    unset( $menu['settings'] );
    return $menu;
}


// Fron End PM: Remove minlength from message title
add_filter( 'fep_form_fields', function( $fields ) {
    unset( $fields['message_title']['minlength'] );
    return $fields;
});

add_filter( 'fep_form_fields', function( $fields ) {
    unset( $fields['message_content']['minlength'] );
    return $fields;
});











